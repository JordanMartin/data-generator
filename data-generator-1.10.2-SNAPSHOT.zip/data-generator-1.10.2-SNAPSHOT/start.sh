#!/bin/sh
export CLASSPATH="bin/*:addons/*"

java io.quarkus.runner.GeneratedMain